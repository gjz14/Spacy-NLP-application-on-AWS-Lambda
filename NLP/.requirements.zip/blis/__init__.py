from .cy import init

init()
